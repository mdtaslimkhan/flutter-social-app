import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:chat_app/video_recoder/settings_repository.dart' as settingRepo;

class TrimVideo extends StatefulWidget {
  final Trimmer trimmer;
  final ValueSetter<String> onVideoSaved;
  final VoidCallback onSkip;
  final double maxLength;
  final String sound;
  final bool showSkip;
  TrimVideo({
    @required this.trimmer,
    @required this.onVideoSaved,
    @required this.onSkip,
    @required this.maxLength,
    @required this.sound,
    @required this.showSkip,
  });


  @override
  _TrimVideoState createState() => _TrimVideoState();
}

class _TrimVideoState extends State<TrimVideo> {
  double _startValue = 0.0;
  double _endValue = 0.0;
  bool _isPlaying = false;
  bool _progressVisibility = false;
  Color appbarColor = Color(0xff2d3d44);
  Color curveColor = Color(0xff1c262d);
  Color textFieldBorderColor = Color(0xff01a684);
  Color buttonColor = Color(0xff01a684);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  Future<String> _saveVideo() async {
    setState(() {
      if (_startValue + widget.maxLength * 1000 < _endValue) {
        _endValue = _startValue + widget.maxLength * 1000;
      }
      _progressVisibility = true;
    });
    String _value = "";

    await widget.trimmer
        .saveTrimmedVideo(ffmpegCommand: " -preset ultrafast ", applyVideoEncoding: widget.showSkip ? false : true,
        startValue: _startValue, endValue: _endValue, customVideoFormat: '.mp4')
        .then((value) {
      setState(() {
        _progressVisibility = true;
        _value = value;
      });
    });
    return _value;
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(statusBarColor: Color(0xff2d3d44), statusBarIconBrightness: Brightness.light),
    );
    return Scaffold(
      backgroundColor: settingRepo.setting.value.bgColor,
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios,
              color: settingRepo.setting.value.iconColor,
            ),
            onPressed: () async {
              Navigator.of(context).pop();
            }),
        iconTheme: IconThemeData(
          size: 16,
          color: settingRepo.setting.value.textColor, //change your color here
        ),
        title: Text("Post"),
        backgroundColor: appbarColor,
        centerTitle: true,
      ),
      body: Builder(
        builder: (context) => Center(
          child: Container(
            padding: EdgeInsets.only(bottom: 30.0),
            color: Colors.black,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Visibility(
                  visible: _progressVisibility,
                  child: LinearProgressIndicator(
                    backgroundColor: Colors.red,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                // Expanded(
                //   child: VideoViewer(
                //    // trimmer: widget.trimmer,
                //   ),
                // ),
                Center(
                  child: TrimEditor(
                    // trimmer: widget.trimmer,
                    viewerHeight: 50.0,
                    viewerWidth: MediaQuery.of(context).size.width - 50,
                    maxVideoLength: Duration(seconds: widget.maxLength.toInt()),
                    onChangeStart: (value) {
                      _startValue = value;
                    },
                    onChangeEnd: (value) {
                      _endValue = value;
                    },
                    onChangePlaybackState: (value) {
                      if (_endValue - _startValue >= widget.maxLength * 1000 + 0.1) {
                        setState(() {
                          _endValue = _startValue + widget.maxLength * 1000;
                        });
                      }
                      setState(() {
                        _isPlaying = value;
                      });
                    },
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          bool playbackState = await widget.trimmer.videPlaybackControl(
                            startValue: _startValue,
                            endValue: _endValue,
                          );

                          setState(() {
                            _isPlaying = playbackState;
                          });
                        },
                        child: Container(
                          height: 40,
                          width: 80,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(3.0), color: buttonColor),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Text(
                                  _isPlaying ? "Pause" : "Play",
                                  style: TextStyle(
                                    color: settingRepo.setting.value.buttonTextColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'RockWellStd',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: widget.showSkip
                          ? InkWell(
                        onTap: () {
                          widget.onSkip();
                        },
                        child: Container(
                          height: 40,
                          width: 80,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(3.0), color: buttonColor),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Text(
                                  "Skip",
                                  style: TextStyle(
                                    color: settingRepo.setting.value.buttonTextColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'RockWellStd',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                          : Container(),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: _progressVisibility
                            ? null
                            : () async {
                          _saveVideo().then((outputPath) {
                            print('========================/////////////=======OUTPUT PATH: $outputPath');
                            final snackBar = SnackBar(
                              content: Text('Video Saved successfully'),
                            );
                            widget.onVideoSaved(outputPath);
                            Scaffold.of(context).showSnackBar(snackBar);
                          });
                        },
                        child: Container(
                          height: 40,
                          width: 80,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(3.0),
                            color: buttonColor,
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Text(
                                  "Save",
                                  style: TextStyle(
                                    color: settingRepo.setting.value.buttonTextColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'RockWellStd',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String durationToString(Duration duration) {
    String twoDigits(var n) {
      if (n >= 10) return "$n";
      return "0$n";
    }

    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(Duration.minutesPerHour));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(Duration.secondsPerMinute));
    return "$twoDigitMinutes:$twoDigitSeconds";
  }
}

